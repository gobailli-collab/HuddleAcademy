Huddle Academy - CIS300 Final Project
Student: Gabriel O. Baillie
ASURITE: gobailli

Website files:
- index.html
- getting-started.html
- training.html
- practice.html
- support.html
- huddle.css
- huddle-logo.svg
- learning-path.svg
- huddle-learning-rhythm.mp4

Before final submission:
1. Upload these files to the root of the HuddleAcademy GitHub repository.
2. Verify GitHub Pages loads every page and all media.
3. Add Google Analytics tracking using your own GA4 measurement ID and capture the required Realtime Overview screenshot.
4. Create the GitHub release named final-submission.
